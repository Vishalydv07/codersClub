import React from 'react'

const SearchFeed = () => {
  return (
    <div>SearchFeed</div>
  )
}

export default SearchFeed